#!/usr/bin/python3

import os
import boto3
import pymysql

# Retrieve Database secret name from AWS SecretsManager
def get_secret_name(secret_tag="db_secrets", region_name="us-east-1"):
    client = boto3.client('secretsmanager', region_name=region_name)
    response = client.list_secrets(
        MaxResults=1,
        Filters=[
            {
                'Key': 'tag-value',
                'Values': [
                    secret_tag,
                ]
            },
        ],
    )
    db_secret = response['SecretList'][0]['Name']
    return db_secret

# Retrieve database credentials from AWS SecretsManager
def get_secret(secret_name, region_name="us-east-1"):
    client = boto3.client('secretsmanager', region_name=region_name)
    response = client.get_secret_value(SecretId=secret_name)
    secret_data = response['SecretString']
    return eval(secret_data)  # Assuming the secret data is stored as a dictionary

# Database credentials retrieved from AWS SecretsManager
db_secret_name = get_secret_name()
db_credentials = get_secret(db_secret_name)

# Establishing the connection
connection = pymysql.connect(user=db_credentials['DB_USERNAME'], password=db_credentials['DB_PASSWORD'], host=db_credentials['DB_ENDPOINT'], database=db_credentials['DB_NAME'])

try:
    # Create a cursor object
    cursor = connection.cursor()
    
    # Executing an MySQL function using the execute() method
    cursor.execute("SELECT DATABASE()")

    # Creating tables as per requirement:
    # Create the product table
    create_product_table = """
    CREATE TABLE product (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(80) NOT NULL
    );
    """
    cursor.execute(create_product_table)

    # Create the reviews table
    create_review_table = """
    CREATE TABLE review (
        id INT PRIMARY KEY AUTO_INCREMENT,
        content VARCHAR(200) NOT NULL,
        product_id INT NOT NULL,
        polarity FLOAT,
        subjectivity FLOAT,
        FOREIGN KEY (product_id) REFERENCES product(id)
    );
    """
    cursor.execute(create_review_table)

    # Commit the changes
    connection.commit()
finally:
    # Close the cursor and connection in the finally block to ensure they are closed even if an exception occurs
    cursor.close()
    connection.close()