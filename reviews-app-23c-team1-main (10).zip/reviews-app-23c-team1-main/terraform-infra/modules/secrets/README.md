# AWS SecretsManager

## Overview
This module has a reusable code to create a secret in AWS SecretsManager
- Secret value could be a string or in the form of four key-value pairs

## Variables
Passing values for those variables in the root main.tf file is required for the module to work :
* secret_name
* secrets