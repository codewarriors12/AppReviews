# AWS RDS 

## Overview
This module has a reusable code to create AWS RDS. It will also create a read-only replica. 
- It allows creating a replica in the same or different Availability Zone as the master DB (same Region).
- It is recomended to have at lease 2 subnets (private) for the Database Subnet group but it can be any number.
- Database and Replica will not have public access
- There is an option to encrypt the storage
- Automated backups enabled. The backup retention period can be changed.

## Variables
Passing values for those variables in the root main.tf file is required for the module to work :

*  storage                         
*  storage_type                   
*  identifier                     
*  db_name                        
*  engine_type                    
*  engine_version                 
*  instance_class                  
*  db_username                    
*  db_password                     
*  skip_final_snapshot             
*  encryption                     
*  rds_sg_id                      
*  private_subnet1_id              
*  private_subnet2_id              
*  db_az                          
*  db_replica_az                 
*  replica_backup_retention_period

## Outputs
For external use, the RDS module outputs those values:
* DataBase Name ("db_username")
* DataBase Password ("db_password")
* DataBase Endpoint ("db_endpoint")
* DataBase Name ("db_name")