# Backend Application AWS AMI Image Creation

## Step by Step Guide

### 1. Launch EC2 Instance
Launch an EC2 instance using the AWS management console. Once set up, connect to the instance using SSH.

### 2. System Updates and Package Installation
Before proceeding, ensure the system packages are updated and the necessary tools are installed:

```bash
# System Update
sudo yum update -y

# Install Python3
sudo yum install python3 -y

# Install Pip
sudo yum install -y pip

# Install Git
sudo yum install git -y
```

### 3. Set Up Git and Clone Repository
**a. Set Up SSH for Git**

Generate and configure an SSH key for Git:

```bash
# Generate SSH key
ssh-keygen -t rsa -b 4096 -C “your_email@example.com”

# Ensure SSH Agent is running and add the key
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_rsa

# Copy the public key for GitHub
cat ~/.ssh/id_rsa.pub
```
**Note**: Add the copied public key to your GitHub SSH keys.

**Clone the Repository**

After setting up SSH for Git:

```bash
git clone git@github.com:312-bc/reviews-app-23c-team1.git
cd api-backend/
```

**b. Alternatively, you can use `scp` to transfer files to the EC2 instance:**

```bash
scp -i (path to your ssh key) -r (path to file/folder you need to copy) ec2-user@public_ip:(path where you want to save your file/folder)
```

### 4. Install Required Python Packages
```bash
pip3 install -r requirements.txt
```

### 5. Boto3 Installation
If necessary, install `boto3` or update the `requirements.txt` with its latest version:

```bash
sudo pip3 install boto3
```

### 6. Configure AWS Secrets
Create a secret with the provided database credentials. This step is for testing purposes; the actual procedure is designated to another team member.

### 7. Permissions
Assign **READ ONLY** permissions to the secret. This policy should be crafted manually; however, Terraform can also automate this in the future.

### 8. AWS IAM Role
Via the AWS console, generate an IAM role with **READ ONLY** permissions for the AWS Secret Manager. This can also be automated with Terraform later on.

### 9. Attach IAM Role to EC2
Navigate to the `actions/security` section and modify the IAM role to connect it to the EC2 instance.

### 10. Modify Python Code
Using `vim` or your preferred editor, adjust the Python code:

```bash
vim app.py
```
Specifically, update the secret's name on line 19.

### 11. MySQL Setup
Install and access MySQL:

```bash
sudo yum install mysql
mysql -h [RDS Endpoint] -u admin -p
```
Note: The password is stored in the secret.

### 12. Database Initialization
Inside the MySQL interface:

```sql
CREATE DATABASE database_name;
USE database_name;

-- Create product and review tables
CREATE TABLE product (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(80) NOT NULL
);

CREATE TABLE review (
    id INT PRIMARY KEY AUTO_INCREMENT,
    content VARCHAR(200) NOT NULL,
    product_id INT NOT NULL,
    polarity FLOAT,
    subjectivity FLOAT,
    FOREIGN KEY (product_id) REFERENCES product(id)
);
```



---

### 13. Create System Service File for the Application

To define a new service for your application, create a system service file:

```bash
sudo vim /etc/systemd/system/reviews-api.service
```

### 14. Service Configuration

Once you've created the file, insert the following configuration into it:

```plaintext
[Unit]
Description=Reviews API Service
After=network.target

[Service]
User=root
Group=ec2-user
WorkingDirectory=/home/ec2-user/api-backend
ExecStart=/usr/bin/python3 /home/ec2-user/api-backend/app.py
Restart=always

[Install]
WantedBy=multi-user.target
```

**Explanation**:

- `[Unit] Section`:
  - **Description**: A brief description of the service.
  - **After**: Specifies when this service should start. In this case, it starts after the network is ready.

- `[Service] Section`:
  - **User**: User that runs the service.
  - **Group**: Group of the user that runs the service.
  - **WorkingDirectory**: Directory from where the service is run.
  - **ExecStart**: Command to start the service.
  - **Restart**: Specifies when to restart the service. Here, it always restarts if it stops.

- `[Install] Section`:
  - **WantedBy**: The system state where this service should be active. In this instance, it's active when the system is in a multi-user state.

---



### 15. File Permissions
Ensure necessary files are executable:

```bash
sudo chmod 755 app.py
```

### 16. Start the Flask Application
```bash
python3 app.py
```

### 17. Manage the Service
To start, enable, and check the service:

```bash
sudo systemctl daemon-reload
sudo systemctl enable reviews-api
sudo systemctl start reviews-api
sudo systemctl status reviews-api
```


---

### 18. Testing

#### POST /product: Adds a New Product

**Request**:
```bash
curl -X POST -H "Content-Type: application/json" -d '{"product_name": "Product Name"}' http://localhost:80/product
```

**Response**:
```json
{
    "message": "Product added successfully",
    "product_id": 1
}
```

#### POST /product/{product_id}/review: Adds a Review for a Product

Replace `{product_id}` with the actual ID of the product you want to add the review for.

**Request**:
```bash
curl -X POST -H "Content-Type: application/json" -d '{"review": "Review content"}' http://localhost:80/product/{product_id}/review
```

**Response**:
```json
{
    "message": "Review added successfully",
    "review_id": 1,
    "polarity": 0.5,
    "subjectivity": 0.6
}
```

#### GET /product: Retrieves a List of All Products

**Request**:
```bash
curl -X GET http://localhost:80/product
```

**Response**:
```json
{
    "products": [
        {
            "id": 1,
            "name": "Product Name 1"
        },
        {
            "id": 2,
            "name": "Product Name 2"
        }
    ]
}
```

#### GET /product/{product_id}/review: Retrieves Reviews for a Specific Product

Replace `{product_id}` with the actual ID of the product for which you want to retrieve the reviews.

**Request**:
```bash
curl -X GET http://localhost:80/product/{product_id}/review
```

**Response**:
```json
{
    "reviews": [
        {
            "id": 1,
            "content": "Review content 1",
            "rating": 8,
            "subjectivity": 0.6
        },
        {
            "id": 2,
            "content": "Review content 2",
            "rating": 7,
            "subjectivity": 0.7
        }
    ]
}
```

---


### 19. Create AWS AMI
Using the AWS console, produce an AMI of your EC2 instance.

**Notes**:
- Ensure the EC2 instance originating from the backend AMI has the SecretManager read-only role attached.
- Confirm that EC2 for AMI created within a public subnet.

