sleep 30 
sudo cp /tmp/index.html /usr/share/nginx/html/
sudo cp /tmp/app.js /usr/share/nginx/html/
sudo cp /tmp/styles_index.css /usr/share/nginx/html/
sudo cp /tmp/logo.png /usr/share/nginx/html/
sudo cp /tmp/Reviews.jpg /usr/share/nginx/html/
sudo cp /tmp/favicon.ico /usr/share/nginx/html/
sudo cp /tmp/styles_ourteam.css /usr/share/nginx/html/
sudo cp /tmp/ourteam.html /usr/share/nginx/html/