## Step by step Creating a Custom Amazon Machine Image (AMI) for Frontend Application with packer 

1. Install packer on your 

   1.1 brew tap hashicorp/tap
   1.2 brew install hashicorp/tap/packer.
   1.3 brew upgrade hashicorp/tap/packer.
   1.4 packer version: This command displays the version of Packer currently installed.


2. Create a packer file could be .json or pkr.hcl
   
3. Export AWS Access & Secrets keys

   3.1 export AWS_ACCESS_KEY=<access_key>
   3.2 export AWS_SECRET_ACCESS_KEY=<secret key>

4. Depends the of the file you choose the value and parameteres will be write different. (In this case I used pkr.hcl file, this is very simiar than terraform.)

   4.1 The first part of the code you have to add the plugs ins for packer.
   
   4.2 Next you have to add sources code in this case have two.
      
      4.2.1 The first one for assume_role.
        4.2.1.1 you will find multiples options to add here but the one we need is role_arn and session_name.

      4.2.2 The second one to create our AMI.
        4.2.2.1 you will find multiples options to add here but the one we need is region, ami_name, source_ami, instance_type, ssh_username (You will have multiple option depending the AMI you chose, ex ec2-user for linux, ubuntu for ubuntu).

    4.3 Third part you have to add build, without this part the ami won't be created, you can add here name, and source (this parte is the source we use  in the last step)


    4.4 The last part is to add provisioners, in this part you will need to add the scripts or configuration mangement need to run.
      
       4.4.1 In our case we use option "shell" to add the steps to install nginx
         4.4.1.1 after shell you have two option to write the commands you need
           
           * inline here you will write all the command in the provisioner (this is good if you only have a few commands)
           
           * script here you will have to create a script file where you'll put all the commands you want to run and you have to specify the location of this file.

      4.4.2 we also use the option "file" this option was use to copy our files from the local machine to the ami when is creating.


5. After we configurate our pkr.hcl file we are ready to run it. 

     5.1 First run packer init [dir]: This command initializes a new Packer configuration in the specified directory.

     5.2 Packer validate [filename]: This command validates the syntax and configuration of the specified Packer file.

     5.3 packer build [filename]: This command builds a new machine image based on the configuration in the specified file.

6. Congratulations you create your first AMI with packer.


## Step by step Creating a Custom Amazon Machine Image (AMI) for Frontend Application console 

1. Launch an EC2 instance through AWS console.

    1.1 Provide a valid Instance name
    1.2 Select Amazon linux 2 
    1.3 Choose the t2.micro instance type
    1.4 Create a key pair for SSH access later 
    1.5 VPC (default)
    1.6 Create Security Group Allowing ports 22 for SSH, 80 for HTTP and 443 for HTTTP, allowing traffic from the internet (0.0.0.0/0). 

2. Verify that Security Group are created Correctly.

3. Change permission of the keyname.pem 
      
    ------> chmod 400 keyname.pem

4. Go to the directory where the key is located and then SSH 

    ----> SSS -i keyname.pem ec2-user@ip_server -y

5. Check internet connection using ping 8.8.8.8 

6. Install ngnix on Amazon linux 2

    6.1 sudo yum updates -y 
    6.2 sudo yum instatll nginx 
    6.3 sudo systemctl start nginx 
    6.4 sudo systemctl enable nginx 
    6.5 sudo systemctl status ( Check if Nginx is running, then test to browser.)

7. Access Nginx via IP addres or DNS in the browser and check if is working. If not the most commond issue is Security Group are not set up correctly.

8. Transfer files from local machine to a VM 
    spc -i path_to_your_keyname.pem Filename.js ec2-user@ip_server:/path_of_the_destination (it should works, if not one of the common reason are you either are in the wrong directory or you give the wrong path)

9. Verify file transfer

    9.1 cd /path_of_the_destination
    9.2 ls (to list the files)

10. Place  front end files (html, css, app.js) into Nginx directory:
    
    10.1 sudo cp /path_of_the_destination/* /usr/share/nginx/html/

11. Edit app.js with backend API DNS name

    11.1 vim /usr/share/nginx/html/apps.js

12. Reload Nginx
    
    12.1 sudo systemctl reload nginx.

13. Access Nginx via IP addres or DNS in the browser and check if is workinng. you should see the review app frontend.

14. After test this in the EC2 machine then is time to create the custom AMI for Frontend application

     14.1 Go to AWS console, navigate to ec2. 
     14.2 Select the instance we have created.
     14.3 Right click, select "Create image"

17. Provide image name and image description.

18. After launching the AMI, Create a ec2 instances using the new AMI.

19. If the AMI is configured properly you should be able to see the same output in the browser that you have in your First EC2 instances.
 
21. AMI ID stored in an AWS parameter store for future references.





